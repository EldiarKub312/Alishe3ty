package com.company;

public class Main {

    public static void main(String[] args) {
        boss boss = new boss();
        boss.getHealth();
        boss.getDamage();
        boss.getProtection();
        boss.printInfo();

    }
}
